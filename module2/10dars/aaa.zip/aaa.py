#1)
# credit=['1924354657687980', '0897867564534231']
#masked_cards = list(map(lambda x: x[:4] + '*' * 8 + x[-4:], credit))
#print(masked_cards)

#2)
# ph_numbers=['+998940182921', '+998508882008']
# masked_num=list(map(lambda x: x[:4] + '*' *4 + x[-4:],ph_numbers))
# print(masked_num)

#3)
# nums = [1, 3, 5, 6, 9, 10, 13, 15, 17, 19]
# nm = list(filter(lambda x: x % 2 != 0 and x % 3 != 0, nums))
# print(nm)

#4)
# nums = [50, 150, 120, 80, 200]
# nm=list(filter(lambda x: x> 100, nums ))
# print(nm)

#5)
# words = ["salom", "dunyo", "hi", "world", "important"]
# out=list(filter(lambda word: len(word) == 5, words))
# print(out)

#6)
# texts = ['salom', 'dunyo']
# out=list(map(lambda word: word[::-1], texts))
# print(out)
